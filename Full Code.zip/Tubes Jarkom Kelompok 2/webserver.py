import socket
import os
import mimetypes
import time
from datetime import datetime
import argparse
import threading

HOST = "0.0.0.0"
TCP_PORT = 8000
UDP_PORT = 9000
BUFFER_SIZE = 4096


def log(message):
    now = datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]
    print(f"{now} [INFO] {message}", flush=True)


def find_root_directory():
    current_dir = os.getcwd()

    candidates = [
        os.path.join(current_dir, "HTML"),
        os.path.join(current_dir, "www"),
        current_dir
    ]

    for folder in candidates:
        if os.path.exists(os.path.join(folder, "index.html")):
            return folder

    return current_dir


ROOT_DIR = find_root_directory()


def get_content_type(file_path):
    content_type, _ = mimetypes.guess_type(file_path)

    if content_type is None:
        return "application/octet-stream"

    if content_type.startswith("text/"):
        return content_type + "; charset=utf-8"

    return content_type


def build_http_response(status_code, status_text, body, content_type="text/html; charset=utf-8"):
    if isinstance(body, str):
        body = body.encode("utf-8")

    header = (
        f"HTTP/1.1 {status_code} {status_text}\r\n"
        f"Content-Type: {content_type}\r\n"
        f"Content-Length: {len(body)}\r\n"
        f"Connection: close\r\n"
        f"Server: Python-Socket-WebServer\r\n"
        f"\r\n"
    ).encode("utf-8")

    return header + body


def safe_join(root, requested_path):
    requested_path = requested_path.lstrip("/")

    if requested_path == "":
        requested_path = "index.html"

    full_path = os.path.abspath(os.path.join(root, requested_path))
    root_abs = os.path.abspath(root)

    if not full_path.startswith(root_abs):
        return None

    return full_path


def handle_http_request(client_socket, client_address, mode_label="SINGLE"):
    start_time = time.time()

    try:
        request_data = client_socket.recv(BUFFER_SIZE)

        if not request_data:
            return

        request_text = request_data.decode("utf-8", errors="ignore")
        request_line = request_text.splitlines()[0]

        parts = request_line.split()

        if len(parts) < 3:
            body = "<html><body><h1>400 Bad Request</h1></body></html>"
            response = build_http_response(400, "Bad Request", body)
            client_socket.sendall(response)

            duration = time.time() - start_time
            log(
                f"[{mode_label}] HTTP client={client_address[0]}:{client_address[1]} | "
                f"path=- | status=400 | duration={duration:.4f}s"
            )
            return

        method = parts[0].upper()
        path = parts[1]

        if method != "GET":
            body = "<html><body><h1>405 Method Not Allowed</h1></body></html>"
            response = build_http_response(405, "Method Not Allowed", body)
            client_socket.sendall(response)

            duration = time.time() - start_time
            log(
                f"[{mode_label}] HTTP client={client_address[0]}:{client_address[1]} | "
                f"path={path} | status=405 | duration={duration:.4f}s"
            )
            return

        file_path = safe_join(ROOT_DIR, path)

        if file_path is None:
            body = "<html><body><h1>403 Forbidden</h1></body></html>"
            response = build_http_response(403, "Forbidden", body)
            client_socket.sendall(response)

            duration = time.time() - start_time
            log(
                f"[{mode_label}] HTTP client={client_address[0]}:{client_address[1]} | "
                f"path={path} | status=403 | duration={duration:.4f}s"
            )
            return

        if os.path.isdir(file_path):
            file_path = os.path.join(file_path, "index.html")

        if not os.path.exists(file_path):
            status_file = os.path.join(ROOT_DIR, "status", "404.html")

            if os.path.exists(status_file):
                with open(status_file, "rb") as f:
                    body = f.read()
            else:
                body = "<html><body><h1>404 Not Found</h1></body></html>"

            response = build_http_response(404, "Not Found", body)
            client_socket.sendall(response)

            duration = time.time() - start_time
            log(
                f"[{mode_label}] HTTP client={client_address[0]}:{client_address[1]} | "
                f"path={path} | status=404 | duration={duration:.4f}s"
            )
            return

        with open(file_path, "rb") as f:
            body = f.read()

        content_type = get_content_type(file_path)
        response = build_http_response(200, "OK", body, content_type)
        client_socket.sendall(response)

        duration = time.time() - start_time
        log(
            f"[{mode_label}] HTTP client={client_address[0]}:{client_address[1]} | "
            f"path={path} | status=200 | file_size={len(body)} | duration={duration:.4f}s"
        )

    except Exception as error:
        body = f"<html><body><h1>500 Internal Server Error</h1><p>{error}</p></body></html>"
        response = build_http_response(500, "Internal Server Error", body)

        try:
            client_socket.sendall(response)
        except Exception:
            pass

        log(f"[{mode_label}] ERROR client={client_address} | {error}")

    finally:
        try:
            client_socket.close()
        except Exception:
            pass


def run_tcp_single_server():
    tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_socket.bind((HOST, TCP_PORT))
    tcp_socket.listen(5)

    log(f"HTTP server SINGLE listen di {HOST}:{TCP_PORT}")
    log(f"Root directory: {ROOT_DIR}")

    while True:
        client_socket, client_address = tcp_socket.accept()

        log(
            f"[SINGLE] HTTP diterima koneksi dari "
            f"{client_address[0]}:{client_address[1]}"
        )

        handle_http_request(client_socket, client_address, "SINGLE")


def run_tcp_multi_server():
    tcp_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_socket.bind((HOST, TCP_PORT))
    tcp_socket.listen(50)

    log(f"HTTP server MULTI listen di {HOST}:{TCP_PORT}")
    log(f"Root directory: {ROOT_DIR}")

    while True:
        client_socket, client_address = tcp_socket.accept()

        log(
            f"[MULTI] HTTP diterima koneksi dari "
            f"{client_address[0]}:{client_address[1]}"
        )

        worker = threading.Thread(
            target=handle_http_request,
            args=(client_socket, client_address, "MULTI"),
            daemon=True
        )
        worker.start()


def run_udp_echo_server():
    udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_socket.bind((HOST, UDP_PORT))

    log(f"UDP Echo Server listen di {HOST}:{UDP_PORT}")

    while True:
        try:
            data, client_address = udp_socket.recvfrom(BUFFER_SIZE)
            udp_socket.sendto(data, client_address)

            log(
                f"[UDP] Echo ke {client_address[0]}:{client_address[1]} | "
                f"bytes={len(data)}"
            )

        except Exception as error:
            log(f"[UDP] ERROR: {error}")


def main():
    parser = argparse.ArgumentParser(description="Web Server TCP/UDP berbasis Socket Python")
    parser.add_argument(
        "--mode",
        choices=["single", "multi"],
        default="single",
        help="Mode web server: single atau multi"
    )

    args = parser.parse_args()

    udp_thread = threading.Thread(target=run_udp_echo_server, daemon=True)
    udp_thread.start()

    if args.mode == "single":
        run_tcp_single_server()

    elif args.mode == "multi":
        run_tcp_multi_server()


if __name__ == "__main__":
    main()