import argparse
import csv
import os
import socket
import statistics
import threading
import time
from datetime import datetime

BUFFER_SIZE = 4096


def now_file():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def recv_all(sock):
    data = b""

    while True:
        try:
            chunk = sock.recv(BUFFER_SIZE)

            if not chunk:
                break

            data += chunk

        except ConnectionResetError:
            # Windows kadang me-reset koneksi setelah server/proxy close.
            # Kalau sudah ada data, tetap gunakan data tersebut.
            break

        except socket.timeout:
            break

    return data


def http_get(proxy_ip, proxy_port, path, show_body=True, save=False):
    if not path.startswith("/"):
        path = "/" + path

    request = (
        f"GET {path} HTTP/1.1\r\n"
        f"Host: {proxy_ip}:{proxy_port}\r\n"
        "User-Agent: Python-Socket-Client\r\n"
        "Connection: close\r\n"
        "\r\n"
    ).encode("iso-8859-1")

    start = time.time()

    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
        sock.settimeout(5)
        sock.connect((proxy_ip, proxy_port))
        sock.sendall(request)
        response = recv_all(sock)

    elapsed_ms = (time.time() - start) * 1000

    header, _, body = response.partition(b"\r\n\r\n")
    header_text = header.decode("iso-8859-1", errors="replace")
    status_line = header_text.splitlines()[0] if header_text else "NO RESPONSE"

    print(f"[TCP] Request path      : {path}")
    print(f"[TCP] Proxy target      : {proxy_ip}:{proxy_port}")
    print(f"[TCP] Status            : {status_line}")
    print(f"[TCP] Response size     : {len(response)} bytes")
    print(f"[TCP] Response time     : {elapsed_ms:.2f} ms")
    print("-" * 60)
    print(header_text)
    print("-" * 60)

    if show_body:
        try:
            print(body.decode("utf-8", errors="replace")[:3000])
            if len(body) > 3000:
                print("\n[Body dipotong di terminal. Gunakan --save untuk menyimpan penuh.]\n")
        except Exception:
            print(f"[Binary body: {len(body)} bytes]")

    if save:
        os.makedirs("result", exist_ok=True)
        filename = os.path.join("result", "response.html")
        with open(filename, "wb") as f:
            f.write(body)
        print(f"[TCP] Body tersimpan ke {filename}")

    return elapsed_ms, status_line, len(response)


def udp_qos(target_ip, target_port, count, timeout, csv_name):
    rtts = []
    rows = []
    sent_payload_bytes = 0
    received_payload_bytes = 0
    start_test = time.time()

    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as sock:
        sock.settimeout(timeout)

        for seq in range(1, count + 1):
            send_time = time.time()
            payload = f"Ping {seq} {send_time}".encode("utf-8")
            sent_payload_bytes += len(payload)

            try:
                sock.sendto(payload, (target_ip, target_port))
                data, addr = sock.recvfrom(65535)

                recv_time = time.time()
                rtt_ms = (recv_time - send_time) * 1000

                rtts.append(rtt_ms)
                received_payload_bytes += len(data)

                print(
                    f"[UDP] seq={seq} reply_from={addr[0]}:{addr[1]} "
                    f"bytes={len(data)} RTT={rtt_ms:.2f} ms"
                )

                rows.append({
                    "seq": seq,
                    "send_timestamp": send_time,
                    "status": "OK",
                    "rtt_ms": round(rtt_ms, 4),
                    "payload_bytes": len(payload),
                })

            except socket.timeout:
                print(f"[UDP] seq={seq} Request timed out")

                rows.append({
                    "seq": seq,
                    "send_timestamp": send_time,
                    "status": "TIMEOUT",
                    "rtt_ms": "",
                    "payload_bytes": len(payload),
                })

            time.sleep(0.2)

    duration = max(time.time() - start_test, 0.000001)
    lost = count - len(rtts)
    loss_percent = (lost / count) * 100

    if rtts:
        min_rtt = min(rtts)
        avg_rtt = sum(rtts) / len(rtts)
        max_rtt = max(rtts)
    else:
        min_rtt = avg_rtt = max_rtt = 0.0

    deltas = [abs(rtts[i] - rtts[i - 1]) for i in range(1, len(rtts))]
    jitter = statistics.pstdev(deltas) if len(deltas) >= 2 else (deltas[0] if deltas else 0.0)

    throughput_kbps = (received_payload_bytes * 8) / duration / 1000

    print("\n========== STATISTIK QoS UDP ==========")
    print(f"Target              : {target_ip}:{target_port}")
    print(f"Packets sent        : {count}")
    print(f"Packets received    : {len(rtts)}")
    print(f"Packet loss         : {loss_percent:.2f}%")
    print(f"RTT min/avg/max     : {min_rtt:.2f}/{avg_rtt:.2f}/{max_rtt:.2f} ms")
    print(f"Jitter              : {jitter:.2f} ms")
    print(f"Throughput          : {throughput_kbps:.4f} kbps")

    os.makedirs("result", exist_ok=True)
    csv_path = os.path.join("result", csv_name)

    with open(csv_path, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(
            f,
            fieldnames=["seq", "send_timestamp", "status", "rtt_ms", "payload_bytes"]
        )

        writer.writeheader()
        writer.writerows(rows)
        writer.writerow({})
        writer.writerow({"seq": "SUMMARY", "status": "sent", "rtt_ms": count})
        writer.writerow({"seq": "SUMMARY", "status": "received", "rtt_ms": len(rtts)})
        writer.writerow({"seq": "SUMMARY", "status": "packet_loss_percent", "rtt_ms": round(loss_percent, 4)})
        writer.writerow({"seq": "SUMMARY", "status": "min_rtt_ms", "rtt_ms": round(min_rtt, 4)})
        writer.writerow({"seq": "SUMMARY", "status": "avg_rtt_ms", "rtt_ms": round(avg_rtt, 4)})
        writer.writerow({"seq": "SUMMARY", "status": "max_rtt_ms", "rtt_ms": round(max_rtt, 4)})
        writer.writerow({"seq": "SUMMARY", "status": "jitter_ms", "rtt_ms": round(jitter, 4)})
        writer.writerow({"seq": "SUMMARY", "status": "throughput_kbps", "rtt_ms": round(throughput_kbps, 4)})

    print(f"[UDP] CSV tersimpan ke {csv_path}")


def run_multi(proxy_ip, proxy_port, path, client_count):
    results = []
    lock = threading.Lock()

    if not path.startswith("/"):
        path = "/" + path

    def worker(client_number):
        try:
            elapsed, status, size = http_get(
                proxy_ip,
                proxy_port,
                path,
                show_body=False,
                save=False
            )

            with lock:
                results.append((client_number, path, status, elapsed, size))

        except Exception as exc:
            with lock:
                results.append((client_number, path, f"ERROR: {exc}", 0, 0))

    print("\n========== MODE MULTI-CLIENT TCP ==========")
    print(f"Proxy target     : {proxy_ip}:{proxy_port}")
    print(f"Jumlah client    : {client_count}")
    print(f"Path HTML        : {path}")
    print("=" * 50)

    threads = []

    for i in range(client_count):
        t = threading.Thread(target=worker, args=(i + 1,))
        threads.append(t)
        t.start()

    for t in threads:
        t.join()

    print("\n========== HASIL MULTI-CLIENT ==========")

    for client_number, path, status, elapsed, size in sorted(results):
        print(
            f"client={client_number} | path={path} | status={status} | "
            f"time={elapsed:.2f}ms | size={size}B"
        )


def main():
    parser = argparse.ArgumentParser(description="Client TCP HTTP + UDP QoS")

    parser.add_argument("--mode", choices=["single", "udp", "multi"], required=True)

    parser.add_argument("--proxy-ip", default="127.0.0.1", help="IP perangkat Proxy")
    parser.add_argument("--proxy-tcp-port", type=int, default=8080)
    parser.add_argument("--proxy-udp-port", type=int, default=9090)

    parser.add_argument("--server-ip", default="127.0.0.1", help="IP Web Server jika UDP langsung ke server")
    parser.add_argument("--server-udp-port", type=int, default=9000)

    parser.add_argument("--udp-target", choices=["proxy", "server"], default="proxy")

    parser.add_argument("--path", default="/index.html", help="Path file HTML yang diminta")
    parser.add_argument("--client", type=int, default=5, help="Jumlah client konkuren untuk mode multi")

    parser.add_argument("--count", type=int, default=10)
    parser.add_argument("--timeout", type=float, default=1.0)
    parser.add_argument("--csv", default=f"qos_result_{now_file()}.csv")
    parser.add_argument("--save", action="store_true")

    args = parser.parse_args()

    if args.mode == "single":
        http_get(
            args.proxy_ip,
            args.proxy_tcp_port,
            args.path,
            show_body=True,
            save=args.save
        )

    elif args.mode == "udp":
        if args.udp_target == "proxy":
            udp_qos(
                args.proxy_ip,
                args.proxy_udp_port,
                args.count,
                args.timeout,
                args.csv
            )
        else:
            udp_qos(
                args.server_ip,
                args.server_udp_port,
                args.count,
                args.timeout,
                args.csv
            )

    elif args.mode == "multi":
        run_multi(
            args.proxy_ip,
            args.proxy_tcp_port,
            args.path,
            args.client
        )


if __name__ == "__main__":
    main()