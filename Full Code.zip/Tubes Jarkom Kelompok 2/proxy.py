import argparse
import os
import socket
import threading
import time
from datetime import datetime

HOST = "0.0.0.0"

PROXY_TCP_PORT = 8080
PROXY_UDP_PORT = 9090

WEB_TCP_PORT = 8000
WEB_UDP_PORT = 9000

BUFFER_SIZE = 4096
ROOT_DIR = "HTML" if os.path.isdir("HTML") else "."

# Cache disimpan di memory/RAM, bukan folder
# Format:
# {
#   "/index.html": b"HTTP/1.1 200 OK..."
# }
CACHE_STORE = {}
CACHE_LOCK = threading.Lock()

STATUS_TEXT = {
    400: "Bad Request",
    502: "Bad Gateway",
    504: "Gateway Timeout",
}


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S,%f")[:-3]


def log(message):
    print(f"{now()} [INFO] {message}", flush=True)


def read_status_page(code):
    status_file = os.path.join(ROOT_DIR, "status", f"{code}.html")

    if os.path.isfile(status_file):
        with open(status_file, "rb") as f:
            return f.read()

    return f"<html><body><h1>{code} {STATUS_TEXT.get(code, 'Error')}</h1></body></html>".encode("utf-8")


def build_response(code, body):
    reason = STATUS_TEXT.get(code, "Error")

    headers = (
        f"HTTP/1.1 {code} {reason}\r\n"
        "Content-Type: text/html; charset=utf-8\r\n"
        f"Content-Length: {len(body)}\r\n"
        "Connection: close\r\n"
        "Server: Python-Socket-Proxy\r\n"
        "\r\n"
    ).encode("iso-8859-1")

    return headers + body


def receive_all(sock):
    data = b""

    while True:
        try:
            chunk = sock.recv(BUFFER_SIZE)
        except socket.timeout:
            raise TimeoutError("socket timeout")

        if not chunk:
            break

        data += chunk

    return data


def receive_http_request(conn):
    data = b""
    conn.settimeout(5)

    while b"\r\n\r\n" not in data:
        chunk = conn.recv(BUFFER_SIZE)

        if not chunk:
            break

        data += chunk

        if len(data) > 1024 * 1024:
            break

    return data


def parse_request_path(request_bytes):
    try:
        text = request_bytes.decode("iso-8859-1", errors="replace")
        first_line = text.split("\r\n", 1)[0]
        parts = first_line.split()

        if len(parts) < 3:
            return None, None

        method = parts[0].upper()
        path = parts[1]

        return method, path

    except Exception:
        return None, None


def get_status_code(response_bytes):
    try:
        first_line = response_bytes.split(b"\r\n", 1)[0].decode("iso-8859-1", errors="replace")
        return int(first_line.split()[1])
    except Exception:
        return 0


def forward_to_web_server(request_bytes, web_ip):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as server_sock:
        server_sock.settimeout(5)
        server_sock.connect((web_ip, WEB_TCP_PORT))
        server_sock.sendall(request_bytes)
        return receive_all(server_sock)


def handle_tcp_client(conn, addr, web_ip):
    start = time.time()

    client_ip, client_port = addr
    thread_name = threading.current_thread().name

    method = "-"
    path = "-"
    cache_status = "-"
    status_code = 0
    response_size = 0

    try:
        request = receive_http_request(conn)
        method, path = parse_request_path(request)

        if method != "GET" or not path:
            response = build_response(400, b"<html><body><h1>400 Bad Request</h1></body></html>")
            conn.sendall(response)
            status_code = 400
            response_size = len(response)
            return

        # =========================
        # CEK CACHE DI MEMORY
        # =========================
        with CACHE_LOCK:
            if path in CACHE_STORE:
                response = CACHE_STORE[path]
                cache_status = "HIT"
            else:
                response = None
                cache_status = "MISS"

        # =========================
        # JIKA CACHE MISS
        # =========================
        if response is None:
            try:
                response = forward_to_web_server(request, web_ip)
                status_code = get_status_code(response)

                if status_code == 0:
                    response = build_response(502, read_status_page(502))

                elif 500 <= status_code <= 599:
                    response = build_response(502, read_status_page(502))

                elif status_code == 200:
                    # Simpan response ke cache memory, bukan folder
                    with CACHE_LOCK:
                        if path not in CACHE_STORE:
                            CACHE_STORE[path] = response

            except (TimeoutError, socket.timeout):
                response = build_response(504, read_status_page(504))

            except Exception:
                response = build_response(502, read_status_page(502))

        status_code = get_status_code(response)
        response_size = len(response)
        conn.sendall(response)

    except Exception as exc:
        try:
            response = build_response(502, read_status_page(502))
            conn.sendall(response)
            response_size = len(response)
            status_code = 502
        except Exception:
            pass

        log(f"[{thread_name}] ERROR client={client_ip}:{client_port} error={exc}")

    finally:
        try:
            conn.close()
        except Exception:
            pass

        duration = time.time() - start

        log(
            f"[TCP] {cache_status} | {client_ip}:{client_port} -> {web_ip}:{WEB_TCP_PORT} "
            f"{method} {path} | status={status_code} | size={response_size}B | "
            f"cache_items={len(CACHE_STORE)} | t={duration:.4f}s"
        )


def run_tcp_proxy(web_ip):
    tcp_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    tcp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    tcp_sock.bind((HOST, PROXY_TCP_PORT))
    tcp_sock.listen(50)

    log("Proxy Server berjalan dengan cache memory/RAM. Tekan Ctrl+C untuk berhenti.")
    log(f"[TCP] Proxy TCP berjalan di {HOST}:{PROXY_TCP_PORT}; target web={web_ip}:{WEB_TCP_PORT}")

    while True:
        conn, addr = tcp_sock.accept()

        worker = threading.Thread(
            target=handle_tcp_client,
            args=(conn, addr, web_ip),
            daemon=True
        )
        worker.start()


def run_udp_proxy(web_ip):
    udp_sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    udp_sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    udp_sock.bind((HOST, PROXY_UDP_PORT))

    log(f"[UDP] Proxy UDP berjalan di {HOST}:{PROXY_UDP_PORT}; target web={web_ip}:{WEB_UDP_PORT}")

    while True:
        data, client_addr = udp_sock.recvfrom(65535)
        start = time.time()

        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server_sock:
                server_sock.settimeout(1)
                server_sock.sendto(data, (web_ip, WEB_UDP_PORT))
                echo, server_addr = server_sock.recvfrom(65535)

            udp_sock.sendto(echo, client_addr)

            duration_ms = (time.time() - start) * 1000

            log(
                f"[UDP] RELAY | {client_addr[0]}:{client_addr[1]} -> {web_ip}:{WEB_UDP_PORT} "
                f"| size={len(data)}B | t={duration_ms:.2f}ms"
            )

        except socket.timeout:
            log(f"[UDP] TIMEOUT | {client_addr[0]}:{client_addr[1]} -> {web_ip}:{WEB_UDP_PORT}")

        except Exception as exc:
            log(f"[UDP] ERROR | {client_addr[0]}:{client_addr[1]} | {exc}")


def main():
    parser = argparse.ArgumentParser(description="Proxy Server TCP cache memory + UDP relay")
    parser.add_argument("--web-ip", default="127.0.0.1", help="IP perangkat Web Server")
    args = parser.parse_args()

    udp_thread = threading.Thread(
        target=run_udp_proxy,
        args=(args.web_ip,),
        daemon=True,
        name="UDP-Proxy-Thread"
    )
    udp_thread.start()

    run_tcp_proxy(args.web_ip)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        log("Proxy Server dihentikan.")