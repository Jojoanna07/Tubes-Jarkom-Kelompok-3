CARA PAKAI CEPAT TUBES JARKOM

Struktur folder yang disarankan:
TUBES_JARKOM/
  client.py
  proxy.py
  webserver.py
  HTML/                 <-- folder HTML dari ZIP, jangan ubah struktur isi foldernya

A. TEST DI SATU LAPTOP / LOCALHOST
1) Terminal 1:
   python webserver.py

2) Terminal 2:
   python proxy.py --web-ip 127.0.0.1

3) Terminal 3 untuk HTTP/TCP:
   python client.py --mode tcp --proxy-ip 127.0.0.1 --path /index.html

4) Test cache HIT/MISS:
   jalankan command nomor 3 dua kali.
   Request pertama harus MISS di proxy, request kedua harus HIT.

5) Test UDP QoS via proxy:
   python client.py --mode udp --proxy-ip 127.0.0.1 --udp-target proxy --count 10

6) Test UDP QoS langsung ke server jika diminta asprak:
   python client.py --mode udp --server-ip 127.0.0.1 --udp-target server --count 10

7) Test multi-client 5 request:
   python client.py --mode multi --proxy-ip 127.0.0.1 --concurrency 5

8) Test browser:
   http://127.0.0.1:8080/index.html

B. TEST 3 DEVICE HOTSPOT
Misal:
- IP Web Server = 192.168.43.10
- IP Proxy = 192.168.43.20
- IP Client = 192.168.43.30

Device Web Server:
   python webserver.py

Device Proxy:
   python proxy.py --web-ip 192.168.43.10

Device Client HTTP/TCP:
   python client.py --mode tcp --proxy-ip 192.168.43.20 --path /index.html

Device Client UDP via proxy:
   python client.py --mode udp --proxy-ip 192.168.43.20 --udp-target proxy --count 10

Browser di Client:
   http://192.168.43.20:8080/index.html

Wireshark di Proxy:
   tcp.port == 8080 || tcp.port == 8000 || udp.port == 9090 || udp.port == 9000

C. CATATAN PENTING
- Kalau antar device tidak connect, izinkan Python di Windows Firewall.
- Webserver dan proxy harus listen di 0.0.0.0 supaya bisa diakses device lain.
- Jangan akses http://IP_WEB_SERVER:8000 dari client saat pengujian final HTTP, karena HTTP harus lewat proxy.
